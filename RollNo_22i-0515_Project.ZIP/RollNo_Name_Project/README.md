# GraphRAG Approach to the NCA Encroach

## Project Information
- **Name**: Usaid Azeem
- **Roll Number**: 22i-0515
- **Department**: Department of AI
- **University**: FAST-NUCES
- **Project Type**: Comparative Analysis (14 marks)

## Description
This project implements a comparative analysis between Traditional RAG (Retrieval-Augmented Generation) and GraphRAG for global sensemaking tasks using UK National Crime Agency (NCA) documents.

## Key Features
- **Controlled Comparison**: Same LLM (Mistral 7B), same dataset (155 NCA PDFs → 1,529 chunks), same chunking strategy
- **Rule-based Entity Extraction**: Deterministic approach (faster, higher quality than LLM-based)
- **Enhanced Knowledge Graph**: 10,417 nodes, 32,806 edges with semantic similarity and cross-cluster bridges
- **Community Detection**: Louvain algorithm (126 communities)
- **Interactive Visualization**: D3.js graph visualization

## Directory Structure
```
RollNo_Name_Project/
├── LaTeX/                    # IEEE Conference Paper
│   ├── main.tex
│   ├── references.bib
│   ├── IEEEtran.cls
│   └── figures/
├── Code/
│   ├── rag/                # Traditional RAG pipeline
│   ├── graphrag/           # GraphRAG implementation
│   └── requirements.txt
├── Results/                 # Evaluation results
└── README.md
```

## Installation
```bash
pip install -r Code/requirements.txt
```

## Usage
1. Start Ollama: `ollama serve`
2. Pull Mistral: `ollama pull mistral`
3. Run RAG: `python Code/rag/rag_pipeline.py "Your question"`
4. Run GraphRAG: `python Code/rag/graphrag/scripts/graphrag_query_v2.py`

## Results Summary
- **Average Response Time**: ~7.2s (both pipelines)
- **GraphRAG Nodes**: 10,417
- **GraphRAG Edges**: 32,806
- **Dataset**: 155 NCA PDFs → 1,529 chunks

## Files with Function Comments
All Python files include detailed function-level comments as required by the assignment guidelines.
